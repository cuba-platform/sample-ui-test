package com.company.uisample.web

import com.company.uisample.web.ui.LoginWindow
import com.company.uisample.web.ui.UserBrowser
import com.company.uisample.web.ui.UserEditor
import com.haulmont.masquerade.components.AppMenu

import org.junit.Test

import static com.codeborne.selenide.Condition.visible
import static com.codeborne.selenide.Selenide.open
import static com.haulmont.masquerade.Components._$
import static com.haulmont.masquerade.Selectors.withText


class UserUiTest {


    @Test
    void createSimpleUser() {

        open("http://localhost:8080/app")

        _$(LoginWindow.class).loginButton.click()

        _$(AppMenu).openItem('administration', 'sec$User.browse')
        _$(UserBrowser).createUser()

        _$(UserEditor).with {
            login.setValue('createdLogin')
            passw.setValue('qO4Hn6o')
            confirmPassw.setValue('qO4Hn6o')

            windowCommit.click()
        }

        _$(UserBrowser).usersTable
                .getCell(withText('createdLogin'))
                .shouldBe(visible)


    }

}
